import React from 'react'

class SampleComponent extends React.Component {
  constructor(props) {
    super(props)
  }

  render() {
    return (
      <div id="sample-component">
        This is my sample component.
      </div>
    )
  }
}

export default SampleComponent
