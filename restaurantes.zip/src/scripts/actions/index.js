export const changeTheme = (theme) => {
  return {
    type: 'CHANGE_THEME',
    theme
  }
}
